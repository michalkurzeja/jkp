<?php

namespace JKP\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JKPCoreBundle extends Bundle
{
}
