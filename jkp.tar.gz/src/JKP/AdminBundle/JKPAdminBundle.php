<?php

namespace JKP\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JKPAdminBundle extends Bundle
{
}
